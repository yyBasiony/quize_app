class ChoiceModel {
  final String text;
  final bool isCorrect;

  ChoiceModel({
    required this.text,
    required this.isCorrect,
  });
}
